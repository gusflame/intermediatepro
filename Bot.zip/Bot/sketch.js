// Using the Twit node package
// https://github.com/ttezel/twit
var Twit = require('twit');

// Pulling all my twitter account info from another file
var config = require('./config.js');

// Making a Twit object for connection to the API
var T = new Twit(config);

// Start once
tweeter();

// Once every N milliseconds
setInterval(tweeter, 60*5*1000);

var tweet;

// Here is the bot!
function tweeter() {

var first = ["drink ","mix ","read ","give money to ","yell at the ","eat ","jump on the "] //verb

var second = ["poop","bees","piss","ginger","babies","bills"] // noun

var end = ["rainbows will be everywhere","your cancer will be cured","you will cure acne","babies will no longer cry","aliens will abduct you", "you will no longer have stomach aches", "your dog will talk"] // result

  // This is a random chooser bot
  tweet = "Today's life hack is: " + first[Math.floor((Math.random()*first.length))]+second[Math.floor((Math.random()*second.length))] + " and then " + end[Math.floor((Math.random()*end.length))] + ".";

  // Post that tweet!
  T.post('statuses/update', { status: tweet }, tweeted);

  // Callback for when the tweet is sent
  function tweeted(err, data, response) {
    if (err) {
      console.log(err);
    } else {
      console.log('Success: ' + data.text);
      //console.log(response);
    }
  };

}