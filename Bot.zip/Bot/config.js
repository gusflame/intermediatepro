//config.js file
module.exports = {
    consumer_key: 'bGSrzr48YbYgjxbEa5FBdod4k',
    consumer_secret: '7Pob9SnzuoyYrX65yCplLnqXw42iAMKwJB8SvCxTJ0VpPZzgoG',
    access_token: '968650198221127680-8Fnkl9RT0o73bGShNOt1WR4n2M4RDfW',
    access_token_secret: 'fsy01g9sJhc0CQPQnCftiJzw055bBfbzjRUMbmN1fdPd0'
}